package com.searchapp.basicsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicsearchApplication {

    public static void main(String[] args) {
        SpringApplication.run(BasicsearchApplication.class, args);
    }

}
