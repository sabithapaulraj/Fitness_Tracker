package com.searchapp.basicsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicsearchApplicationTests {

    @Test
    void contextLoads() {
    }

}
