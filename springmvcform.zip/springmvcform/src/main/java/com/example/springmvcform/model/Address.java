package com.example.springmvcform.model;

import lombok.Data;

@Data
public class Address {
    private String city;
    private String state;
}
