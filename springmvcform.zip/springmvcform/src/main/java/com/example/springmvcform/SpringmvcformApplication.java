package com.example.springmvcform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmvcformApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringmvcformApplication.class, args);
    }

}
