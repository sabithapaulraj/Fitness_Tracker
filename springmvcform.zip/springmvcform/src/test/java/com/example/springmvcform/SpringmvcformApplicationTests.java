package com.example.springmvcform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmvcformApplicationTests {

    @Test
    void contextLoads() {
    }

}
